﻿
namespace WindowsFormsApp1.Forms
{
    partial class ConsultaEmpresa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ConsultaEmpresa));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnAjuda = new System.Windows.Forms.Button();
            this.btnFechar = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.nineDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nuitDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nomeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.abreviaturaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.moradaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cPostalDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.faxDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.eMailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.telefoneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.caminhoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.localidadeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.homensDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mulheresDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.latDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.longtudeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.altDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.volumeVendasDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataConstituicaoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.capitalSocialDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.situaçãoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pubDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.privDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.estrDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.formaJuridicaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contaEmpresaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gciDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cArtComercialDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataDocumentoRecenteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sectorInstituicionalDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nrEstabelecimentosDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idempresaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fuedbBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.fue_dbDataSet1 = new WindowsFormsApp1.fue_dbDataSet1();
            this.fue_dbTableAdapter = new WindowsFormsApp1.fue_dbDataSet1TableAdapters.fue_dbTableAdapter();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fuedbBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fue_dbDataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.textBox2);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1366, 100);
            this.panel1.TabIndex = 0;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(3, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(172, 65);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox2.TabIndex = 34;
            this.pictureBox2.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label3.Location = new System.Drawing.Point(38, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(211, 25);
            this.label3.TabIndex = 32;
            this.label3.Text = "Consultar Empresas";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label2.Location = new System.Drawing.Point(688, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 21);
            this.label2.TabIndex = 18;
            this.label2.Text = "Nº Nuit";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label1.Location = new System.Drawing.Point(487, 57);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 21);
            this.label1.TabIndex = 15;
            this.label1.Text = "Nº INE";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(758, 56);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 17;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(550, 58);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 16;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnAjuda);
            this.panel2.Controls.Add(this.btnFechar);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 445);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1366, 43);
            this.panel2.TabIndex = 1;
            // 
            // btnAjuda
            // 
            this.btnAjuda.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnAjuda.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAjuda.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAjuda.ForeColor = System.Drawing.Color.White;
            this.btnAjuda.Location = new System.Drawing.Point(737, 3);
            this.btnAjuda.Name = "btnAjuda";
            this.btnAjuda.Size = new System.Drawing.Size(242, 35);
            this.btnAjuda.TabIndex = 32;
            this.btnAjuda.Text = "Ajuda";
            this.btnAjuda.UseVisualStyleBackColor = false;
            // 
            // btnFechar
            // 
            this.btnFechar.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnFechar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFechar.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFechar.ForeColor = System.Drawing.Color.White;
            this.btnFechar.Location = new System.Drawing.Point(490, 3);
            this.btnFechar.Name = "btnFechar";
            this.btnFechar.Size = new System.Drawing.Size(242, 35);
            this.btnFechar.TabIndex = 31;
            this.btnFechar.Text = "Fechar";
            this.btnFechar.UseVisualStyleBackColor = false;
            this.btnFechar.Click += new System.EventHandler(this.btnFechar_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nineDataGridViewTextBoxColumn,
            this.nuitDataGridViewTextBoxColumn,
            this.nomeDataGridViewTextBoxColumn,
            this.abreviaturaDataGridViewTextBoxColumn,
            this.moradaDataGridViewTextBoxColumn,
            this.cPostalDataGridViewTextBoxColumn,
            this.faxDataGridViewTextBoxColumn,
            this.eMailDataGridViewTextBoxColumn,
            this.telefoneDataGridViewTextBoxColumn,
            this.caminhoDataGridViewTextBoxColumn,
            this.localidadeDataGridViewTextBoxColumn,
            this.homensDataGridViewTextBoxColumn,
            this.mulheresDataGridViewTextBoxColumn,
            this.latDataGridViewTextBoxColumn,
            this.longtudeDataGridViewTextBoxColumn,
            this.altDataGridViewTextBoxColumn,
            this.volumeVendasDataGridViewTextBoxColumn,
            this.dataConstituicaoDataGridViewTextBoxColumn,
            this.capitalSocialDataGridViewTextBoxColumn,
            this.situaçãoDataGridViewTextBoxColumn,
            this.pubDataGridViewTextBoxColumn,
            this.privDataGridViewTextBoxColumn,
            this.estrDataGridViewTextBoxColumn,
            this.formaJuridicaDataGridViewTextBoxColumn,
            this.contaEmpresaDataGridViewTextBoxColumn,
            this.gciDataGridViewTextBoxColumn,
            this.cArtComercialDataGridViewTextBoxColumn,
            this.dataDocumentoRecenteDataGridViewTextBoxColumn,
            this.sectorInstituicionalDataGridViewTextBoxColumn,
            this.nrEstabelecimentosDataGridViewTextBoxColumn,
            this.idempresaDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.fuedbBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(57, 106);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1242, 336);
            this.dataGridView1.TabIndex = 2;
            // 
            // nineDataGridViewTextBoxColumn
            // 
            this.nineDataGridViewTextBoxColumn.DataPropertyName = "nine";
            this.nineDataGridViewTextBoxColumn.HeaderText = "nine";
            this.nineDataGridViewTextBoxColumn.Name = "nineDataGridViewTextBoxColumn";
            // 
            // nuitDataGridViewTextBoxColumn
            // 
            this.nuitDataGridViewTextBoxColumn.DataPropertyName = "nuit";
            this.nuitDataGridViewTextBoxColumn.HeaderText = "nuit";
            this.nuitDataGridViewTextBoxColumn.Name = "nuitDataGridViewTextBoxColumn";
            // 
            // nomeDataGridViewTextBoxColumn
            // 
            this.nomeDataGridViewTextBoxColumn.DataPropertyName = "nome";
            this.nomeDataGridViewTextBoxColumn.HeaderText = "nome";
            this.nomeDataGridViewTextBoxColumn.Name = "nomeDataGridViewTextBoxColumn";
            // 
            // abreviaturaDataGridViewTextBoxColumn
            // 
            this.abreviaturaDataGridViewTextBoxColumn.DataPropertyName = "abreviatura";
            this.abreviaturaDataGridViewTextBoxColumn.HeaderText = "abreviatura";
            this.abreviaturaDataGridViewTextBoxColumn.Name = "abreviaturaDataGridViewTextBoxColumn";
            // 
            // moradaDataGridViewTextBoxColumn
            // 
            this.moradaDataGridViewTextBoxColumn.DataPropertyName = "morada";
            this.moradaDataGridViewTextBoxColumn.HeaderText = "morada";
            this.moradaDataGridViewTextBoxColumn.Name = "moradaDataGridViewTextBoxColumn";
            // 
            // cPostalDataGridViewTextBoxColumn
            // 
            this.cPostalDataGridViewTextBoxColumn.DataPropertyName = "cPostal";
            this.cPostalDataGridViewTextBoxColumn.HeaderText = "cPostal";
            this.cPostalDataGridViewTextBoxColumn.Name = "cPostalDataGridViewTextBoxColumn";
            // 
            // faxDataGridViewTextBoxColumn
            // 
            this.faxDataGridViewTextBoxColumn.DataPropertyName = "fax";
            this.faxDataGridViewTextBoxColumn.HeaderText = "fax";
            this.faxDataGridViewTextBoxColumn.Name = "faxDataGridViewTextBoxColumn";
            // 
            // eMailDataGridViewTextBoxColumn
            // 
            this.eMailDataGridViewTextBoxColumn.DataPropertyName = "eMail";
            this.eMailDataGridViewTextBoxColumn.HeaderText = "eMail";
            this.eMailDataGridViewTextBoxColumn.Name = "eMailDataGridViewTextBoxColumn";
            // 
            // telefoneDataGridViewTextBoxColumn
            // 
            this.telefoneDataGridViewTextBoxColumn.DataPropertyName = "telefone";
            this.telefoneDataGridViewTextBoxColumn.HeaderText = "telefone";
            this.telefoneDataGridViewTextBoxColumn.Name = "telefoneDataGridViewTextBoxColumn";
            // 
            // caminhoDataGridViewTextBoxColumn
            // 
            this.caminhoDataGridViewTextBoxColumn.DataPropertyName = "caminho";
            this.caminhoDataGridViewTextBoxColumn.HeaderText = "caminho";
            this.caminhoDataGridViewTextBoxColumn.Name = "caminhoDataGridViewTextBoxColumn";
            // 
            // localidadeDataGridViewTextBoxColumn
            // 
            this.localidadeDataGridViewTextBoxColumn.DataPropertyName = "localidade";
            this.localidadeDataGridViewTextBoxColumn.HeaderText = "localidade";
            this.localidadeDataGridViewTextBoxColumn.Name = "localidadeDataGridViewTextBoxColumn";
            // 
            // homensDataGridViewTextBoxColumn
            // 
            this.homensDataGridViewTextBoxColumn.DataPropertyName = "homens";
            this.homensDataGridViewTextBoxColumn.HeaderText = "homens";
            this.homensDataGridViewTextBoxColumn.Name = "homensDataGridViewTextBoxColumn";
            // 
            // mulheresDataGridViewTextBoxColumn
            // 
            this.mulheresDataGridViewTextBoxColumn.DataPropertyName = "mulheres";
            this.mulheresDataGridViewTextBoxColumn.HeaderText = "mulheres";
            this.mulheresDataGridViewTextBoxColumn.Name = "mulheresDataGridViewTextBoxColumn";
            // 
            // latDataGridViewTextBoxColumn
            // 
            this.latDataGridViewTextBoxColumn.DataPropertyName = "lat";
            this.latDataGridViewTextBoxColumn.HeaderText = "lat";
            this.latDataGridViewTextBoxColumn.Name = "latDataGridViewTextBoxColumn";
            // 
            // longtudeDataGridViewTextBoxColumn
            // 
            this.longtudeDataGridViewTextBoxColumn.DataPropertyName = "longtude";
            this.longtudeDataGridViewTextBoxColumn.HeaderText = "longtude";
            this.longtudeDataGridViewTextBoxColumn.Name = "longtudeDataGridViewTextBoxColumn";
            // 
            // altDataGridViewTextBoxColumn
            // 
            this.altDataGridViewTextBoxColumn.DataPropertyName = "alt";
            this.altDataGridViewTextBoxColumn.HeaderText = "alt";
            this.altDataGridViewTextBoxColumn.Name = "altDataGridViewTextBoxColumn";
            // 
            // volumeVendasDataGridViewTextBoxColumn
            // 
            this.volumeVendasDataGridViewTextBoxColumn.DataPropertyName = "volumeVendas";
            this.volumeVendasDataGridViewTextBoxColumn.HeaderText = "volumeVendas";
            this.volumeVendasDataGridViewTextBoxColumn.Name = "volumeVendasDataGridViewTextBoxColumn";
            // 
            // dataConstituicaoDataGridViewTextBoxColumn
            // 
            this.dataConstituicaoDataGridViewTextBoxColumn.DataPropertyName = "dataConstituicao";
            this.dataConstituicaoDataGridViewTextBoxColumn.HeaderText = "dataConstituicao";
            this.dataConstituicaoDataGridViewTextBoxColumn.Name = "dataConstituicaoDataGridViewTextBoxColumn";
            // 
            // capitalSocialDataGridViewTextBoxColumn
            // 
            this.capitalSocialDataGridViewTextBoxColumn.DataPropertyName = "capitalSocial";
            this.capitalSocialDataGridViewTextBoxColumn.HeaderText = "capitalSocial";
            this.capitalSocialDataGridViewTextBoxColumn.Name = "capitalSocialDataGridViewTextBoxColumn";
            // 
            // situaçãoDataGridViewTextBoxColumn
            // 
            this.situaçãoDataGridViewTextBoxColumn.DataPropertyName = "situação";
            this.situaçãoDataGridViewTextBoxColumn.HeaderText = "situação";
            this.situaçãoDataGridViewTextBoxColumn.Name = "situaçãoDataGridViewTextBoxColumn";
            // 
            // pubDataGridViewTextBoxColumn
            // 
            this.pubDataGridViewTextBoxColumn.DataPropertyName = "pub";
            this.pubDataGridViewTextBoxColumn.HeaderText = "pub";
            this.pubDataGridViewTextBoxColumn.Name = "pubDataGridViewTextBoxColumn";
            // 
            // privDataGridViewTextBoxColumn
            // 
            this.privDataGridViewTextBoxColumn.DataPropertyName = "priv";
            this.privDataGridViewTextBoxColumn.HeaderText = "priv";
            this.privDataGridViewTextBoxColumn.Name = "privDataGridViewTextBoxColumn";
            // 
            // estrDataGridViewTextBoxColumn
            // 
            this.estrDataGridViewTextBoxColumn.DataPropertyName = "estr";
            this.estrDataGridViewTextBoxColumn.HeaderText = "estr";
            this.estrDataGridViewTextBoxColumn.Name = "estrDataGridViewTextBoxColumn";
            // 
            // formaJuridicaDataGridViewTextBoxColumn
            // 
            this.formaJuridicaDataGridViewTextBoxColumn.DataPropertyName = "formaJuridica";
            this.formaJuridicaDataGridViewTextBoxColumn.HeaderText = "formaJuridica";
            this.formaJuridicaDataGridViewTextBoxColumn.Name = "formaJuridicaDataGridViewTextBoxColumn";
            // 
            // contaEmpresaDataGridViewTextBoxColumn
            // 
            this.contaEmpresaDataGridViewTextBoxColumn.DataPropertyName = "ContaEmpresa";
            this.contaEmpresaDataGridViewTextBoxColumn.HeaderText = "ContaEmpresa";
            this.contaEmpresaDataGridViewTextBoxColumn.Name = "contaEmpresaDataGridViewTextBoxColumn";
            // 
            // gciDataGridViewTextBoxColumn
            // 
            this.gciDataGridViewTextBoxColumn.DataPropertyName = "gci";
            this.gciDataGridViewTextBoxColumn.HeaderText = "gci";
            this.gciDataGridViewTextBoxColumn.Name = "gciDataGridViewTextBoxColumn";
            // 
            // cArtComercialDataGridViewTextBoxColumn
            // 
            this.cArtComercialDataGridViewTextBoxColumn.DataPropertyName = "CArtComercial";
            this.cArtComercialDataGridViewTextBoxColumn.HeaderText = "CArtComercial";
            this.cArtComercialDataGridViewTextBoxColumn.Name = "cArtComercialDataGridViewTextBoxColumn";
            // 
            // dataDocumentoRecenteDataGridViewTextBoxColumn
            // 
            this.dataDocumentoRecenteDataGridViewTextBoxColumn.DataPropertyName = "DataDocumentoRecente";
            this.dataDocumentoRecenteDataGridViewTextBoxColumn.HeaderText = "DataDocumentoRecente";
            this.dataDocumentoRecenteDataGridViewTextBoxColumn.Name = "dataDocumentoRecenteDataGridViewTextBoxColumn";
            // 
            // sectorInstituicionalDataGridViewTextBoxColumn
            // 
            this.sectorInstituicionalDataGridViewTextBoxColumn.DataPropertyName = "sectorInstituicional";
            this.sectorInstituicionalDataGridViewTextBoxColumn.HeaderText = "sectorInstituicional";
            this.sectorInstituicionalDataGridViewTextBoxColumn.Name = "sectorInstituicionalDataGridViewTextBoxColumn";
            // 
            // nrEstabelecimentosDataGridViewTextBoxColumn
            // 
            this.nrEstabelecimentosDataGridViewTextBoxColumn.DataPropertyName = "nrEstabelecimentos";
            this.nrEstabelecimentosDataGridViewTextBoxColumn.HeaderText = "nrEstabelecimentos";
            this.nrEstabelecimentosDataGridViewTextBoxColumn.Name = "nrEstabelecimentosDataGridViewTextBoxColumn";
            // 
            // idempresaDataGridViewTextBoxColumn
            // 
            this.idempresaDataGridViewTextBoxColumn.DataPropertyName = "id_empresa";
            this.idempresaDataGridViewTextBoxColumn.HeaderText = "id_empresa";
            this.idempresaDataGridViewTextBoxColumn.Name = "idempresaDataGridViewTextBoxColumn";
            this.idempresaDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // fuedbBindingSource
            // 
            this.fuedbBindingSource.DataMember = "fue_db";
            this.fuedbBindingSource.DataSource = this.fue_dbDataSet1;
            // 
            // fue_dbDataSet1
            // 
            this.fue_dbDataSet1.DataSetName = "fue_dbDataSet1";
            this.fue_dbDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // fue_dbTableAdapter
            // 
            this.fue_dbTableAdapter.ClearBeforeFill = true;
            // 
            // ConsultaEmpresa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1366, 488);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "ConsultaEmpresa";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ConsultaEmpresa";
            this.Load += new System.EventHandler(this.ConsultaEmpresa_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fuedbBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fue_dbDataSet1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnAjuda;
        private System.Windows.Forms.Button btnFechar;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private fue_dbDataSet1 fue_dbDataSet1;
        private System.Windows.Forms.BindingSource fuedbBindingSource;
        private fue_dbDataSet1TableAdapters.fue_dbTableAdapter fue_dbTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn nineDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nuitDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn abreviaturaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn moradaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cPostalDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn faxDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn eMailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn telefoneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn caminhoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn localidadeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn homensDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mulheresDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn latDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn longtudeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn altDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn volumeVendasDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataConstituicaoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn capitalSocialDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn situaçãoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pubDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn privDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn estrDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn formaJuridicaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn contaEmpresaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gciDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cArtComercialDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataDocumentoRecenteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sectorInstituicionalDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nrEstabelecimentosDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idempresaDataGridViewTextBoxColumn;
    }
}