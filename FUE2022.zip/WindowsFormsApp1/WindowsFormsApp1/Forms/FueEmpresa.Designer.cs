﻿
namespace WindowsFormsApp1.Forms
{
    partial class FueEmpresa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FueEmpresa));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnPesquisar = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.txtDoc = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtNuit = new System.Windows.Forms.TextBox();
            this.txtNine = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtAlt = new System.Windows.Forms.TextBox();
            this.txtLong = new System.Windows.Forms.TextBox();
            this.txtLat = new System.Windows.Forms.TextBox();
            this.txtNrEstabelecimentos = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dtpDocumentoRecente = new System.Windows.Forms.DateTimePicker();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.dtpConstituicao = new System.Windows.Forms.DateTimePicker();
            this.txtAbreviatura = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtGci = new System.Windows.Forms.TextBox();
            this.txtMorada = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtEst = new System.Windows.Forms.TextBox();
            this.txtCPostal = new System.Windows.Forms.TextBox();
            this.txtPriv = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtPub = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtSector = new System.Windows.Forms.TextBox();
            this.txtUrl = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtComercial = new System.Windows.Forms.TextBox();
            this.txtLocalidade = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtContaEmpresa = new System.Windows.Forms.TextBox();
            this.txtFax = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.txtTelefone = new System.Windows.Forms.TextBox();
            this.txtFormaJuridica = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtSituacao = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.txtCapital = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txtMulheres = new System.Windows.Forms.TextBox();
            this.txtVVendas = new System.Windows.Forms.TextBox();
            this.txtHomens = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.btnAjuda = new System.Windows.Forms.Button();
            this.btnFechar = new System.Windows.Forms.Button();
            this.btnAlterar = new System.Windows.Forms.Button();
            this.btnSEmpresa = new System.Windows.Forms.Button();
            this.btnEstEmpresa = new System.Windows.Forms.Button();
            this.btnActividadeEmpresa = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnNovoRegistro = new System.Windows.Forms.Button();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel1.Controls.Add(this.btnPesquisar);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.txtDoc);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.txtNuit);
            this.panel1.Controls.Add(this.txtNine);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1250, 124);
            this.panel1.TabIndex = 0;
            // 
            // btnPesquisar
            // 
            this.btnPesquisar.BackColor = System.Drawing.Color.Gray;
            this.btnPesquisar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPesquisar.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPesquisar.ForeColor = System.Drawing.Color.White;
            this.btnPesquisar.Location = new System.Drawing.Point(1000, 75);
            this.btnPesquisar.Name = "btnPesquisar";
            this.btnPesquisar.Size = new System.Drawing.Size(212, 35);
            this.btnPesquisar.TabIndex = 36;
            this.btnPesquisar.Text = "Pesquisar";
            this.btnPesquisar.UseVisualStyleBackColor = false;
            this.btnPesquisar.Click += new System.EventHandler(this.btnPesquisar_Click_1);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(12, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(172, 65);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox2.TabIndex = 35;
            this.pictureBox2.TabStop = false;
            // 
            // txtDoc
            // 
            this.txtDoc.Location = new System.Drawing.Point(400, 86);
            this.txtDoc.Name = "txtDoc";
            this.txtDoc.Size = new System.Drawing.Size(100, 20);
            this.txtDoc.TabIndex = 13;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Gray;
            this.label3.Location = new System.Drawing.Point(290, 85);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(104, 21);
            this.label3.TabIndex = 12;
            this.label3.Text = "Documento";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Gray;
            this.label2.Location = new System.Drawing.Point(742, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 21);
            this.label2.TabIndex = 11;
            this.label2.Text = "Nº Nuit";
            // 
            // txtNuit
            // 
            this.txtNuit.Location = new System.Drawing.Point(812, 85);
            this.txtNuit.Name = "txtNuit";
            this.txtNuit.Size = new System.Drawing.Size(100, 20);
            this.txtNuit.TabIndex = 10;
            // 
            // txtNine
            // 
            this.txtNine.Location = new System.Drawing.Point(604, 87);
            this.txtNine.Name = "txtNine";
            this.txtNine.Size = new System.Drawing.Size(100, 20);
            this.txtNine.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gray;
            this.label1.Location = new System.Drawing.Point(541, 86);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 21);
            this.label1.TabIndex = 8;
            this.label1.Text = "Nº INE";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel2.Controls.Add(this.txtAlt);
            this.panel2.Controls.Add(this.txtLong);
            this.panel2.Controls.Add(this.txtLat);
            this.panel2.Controls.Add(this.txtNrEstabelecimentos);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label26);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.dtpDocumentoRecente);
            this.panel2.Controls.Add(this.txtNome);
            this.panel2.Controls.Add(this.dtpConstituicao);
            this.panel2.Controls.Add(this.txtAbreviatura);
            this.panel2.Controls.Add(this.label25);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.txtGci);
            this.panel2.Controls.Add(this.txtMorada);
            this.panel2.Controls.Add(this.label24);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.txtEst);
            this.panel2.Controls.Add(this.txtCPostal);
            this.panel2.Controls.Add(this.txtPriv);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.txtPub);
            this.panel2.Controls.Add(this.txtEmail);
            this.panel2.Controls.Add(this.label23);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.txtSector);
            this.panel2.Controls.Add(this.txtUrl);
            this.panel2.Controls.Add(this.label22);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.txtComercial);
            this.panel2.Controls.Add(this.txtLocalidade);
            this.panel2.Controls.Add(this.label21);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.txtContaEmpresa);
            this.panel2.Controls.Add(this.txtFax);
            this.panel2.Controls.Add(this.label20);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.label19);
            this.panel2.Controls.Add(this.txtTelefone);
            this.panel2.Controls.Add(this.txtFormaJuridica);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.txtSituacao);
            this.panel2.Controls.Add(this.label18);
            this.panel2.Controls.Add(this.label14);
            this.panel2.Controls.Add(this.txtCapital);
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.label17);
            this.panel2.Controls.Add(this.txtMulheres);
            this.panel2.Controls.Add(this.txtVVendas);
            this.panel2.Controls.Add(this.txtHomens);
            this.panel2.Controls.Add(this.label16);
            this.panel2.Location = new System.Drawing.Point(255, 124);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(995, 383);
            this.panel2.TabIndex = 1;
            // 
            // txtAlt
            // 
            this.txtAlt.Location = new System.Drawing.Point(664, 156);
            this.txtAlt.Name = "txtAlt";
            this.txtAlt.Size = new System.Drawing.Size(118, 20);
            this.txtAlt.TabIndex = 109;
            // 
            // txtLong
            // 
            this.txtLong.Location = new System.Drawing.Point(532, 156);
            this.txtLong.Name = "txtLong";
            this.txtLong.Size = new System.Drawing.Size(118, 20);
            this.txtLong.TabIndex = 108;
            // 
            // txtLat
            // 
            this.txtLat.Location = new System.Drawing.Point(400, 156);
            this.txtLat.Name = "txtLat";
            this.txtLat.Size = new System.Drawing.Size(118, 20);
            this.txtLat.TabIndex = 107;
            // 
            // txtNrEstabelecimentos
            // 
            this.txtNrEstabelecimentos.Location = new System.Drawing.Point(13, 312);
            this.txtNrEstabelecimentos.Name = "txtNrEstabelecimentos";
            this.txtNrEstabelecimentos.Size = new System.Drawing.Size(178, 20);
            this.txtNrEstabelecimentos.TabIndex = 106;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(394, 35);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 20);
            this.label5.TabIndex = 61;
            this.label5.Text = "Abreviatura";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.White;
            this.label26.Location = new System.Drawing.Point(10, 287);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(182, 20);
            this.label26.TabIndex = 105;
            this.label26.Text = "Nº de Estabelecimentos";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(9, 35);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 20);
            this.label4.TabIndex = 58;
            this.label4.Text = "Nome";
            // 
            // dtpDocumentoRecente
            // 
            this.dtpDocumentoRecente.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDocumentoRecente.Location = new System.Drawing.Point(197, 312);
            this.dtpDocumentoRecente.Name = "dtpDocumentoRecente";
            this.dtpDocumentoRecente.Size = new System.Drawing.Size(176, 20);
            this.dtpDocumentoRecente.TabIndex = 104;
            this.dtpDocumentoRecente.Value = new System.DateTime(2022, 12, 14, 8, 23, 3, 0);
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(13, 59);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(367, 20);
            this.txtNome.TabIndex = 60;
            // 
            // dtpConstituicao
            // 
            this.dtpConstituicao.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpConstituicao.Location = new System.Drawing.Point(802, 156);
            this.dtpConstituicao.Name = "dtpConstituicao";
            this.dtpConstituicao.Size = new System.Drawing.Size(186, 20);
            this.dtpConstituicao.TabIndex = 103;
            // 
            // txtAbreviatura
            // 
            this.txtAbreviatura.Location = new System.Drawing.Point(398, 59);
            this.txtAbreviatura.Name = "txtAbreviatura";
            this.txtAbreviatura.Size = new System.Drawing.Size(186, 20);
            this.txtAbreviatura.TabIndex = 59;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.White;
            this.label25.Location = new System.Drawing.Point(193, 287);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(202, 20);
            this.label25.TabIndex = 102;
            this.label25.Text = "Data documento Recente";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(594, 35);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 20);
            this.label6.TabIndex = 62;
            this.label6.Text = "Morada";
            // 
            // txtGci
            // 
            this.txtGci.Location = new System.Drawing.Point(802, 260);
            this.txtGci.Name = "txtGci";
            this.txtGci.Size = new System.Drawing.Size(186, 20);
            this.txtGci.TabIndex = 101;
            // 
            // txtMorada
            // 
            this.txtMorada.Location = new System.Drawing.Point(598, 59);
            this.txtMorada.Name = "txtMorada";
            this.txtMorada.Size = new System.Drawing.Size(186, 20);
            this.txtMorada.TabIndex = 63;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.White;
            this.label24.Location = new System.Drawing.Point(798, 237);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(39, 20);
            this.label24.TabIndex = 100;
            this.label24.Text = "GCI";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(798, 35);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 20);
            this.label7.TabIndex = 64;
            this.label7.Text = "C. Postal";
            // 
            // txtEst
            // 
            this.txtEst.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEst.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.txtEst.Location = new System.Drawing.Point(728, 260);
            this.txtEst.Name = "txtEst";
            this.txtEst.Size = new System.Drawing.Size(56, 22);
            this.txtEst.TabIndex = 99;
            // 
            // txtCPostal
            // 
            this.txtCPostal.Location = new System.Drawing.Point(802, 59);
            this.txtCPostal.Name = "txtCPostal";
            this.txtCPostal.Size = new System.Drawing.Size(186, 20);
            this.txtCPostal.TabIndex = 65;
            // 
            // txtPriv
            // 
            this.txtPriv.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPriv.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.txtPriv.Location = new System.Drawing.Point(663, 260);
            this.txtPriv.Name = "txtPriv";
            this.txtPriv.Size = new System.Drawing.Size(56, 22);
            this.txtPriv.TabIndex = 98;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(9, 82);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(51, 20);
            this.label8.TabIndex = 66;
            this.label8.Text = "E-mail";
            // 
            // txtPub
            // 
            this.txtPub.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPub.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.txtPub.Location = new System.Drawing.Point(598, 260);
            this.txtPub.Name = "txtPub";
            this.txtPub.Size = new System.Drawing.Size(56, 22);
            this.txtPub.TabIndex = 97;
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(13, 106);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(367, 20);
            this.txtEmail.TabIndex = 67;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.White;
            this.label23.Location = new System.Drawing.Point(594, 237);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(173, 20);
            this.label23.TabIndex = 96;
            this.label23.Text = "Repartição Do Capital";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(394, 82);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(36, 20);
            this.label9.TabIndex = 68;
            this.label9.Text = "URL";
            // 
            // txtSector
            // 
            this.txtSector.Location = new System.Drawing.Point(398, 260);
            this.txtSector.Name = "txtSector";
            this.txtSector.Size = new System.Drawing.Size(186, 20);
            this.txtSector.TabIndex = 95;
            // 
            // txtUrl
            // 
            this.txtUrl.Location = new System.Drawing.Point(398, 106);
            this.txtUrl.Name = "txtUrl";
            this.txtUrl.Size = new System.Drawing.Size(386, 20);
            this.txtUrl.TabIndex = 69;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(394, 237);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(147, 20);
            this.label22.TabIndex = 94;
            this.label22.Text = "Sector Institucional";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(798, 82);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(92, 20);
            this.label10.TabIndex = 70;
            this.label10.Text = "Localidade";
            // 
            // txtComercial
            // 
            this.txtComercial.Location = new System.Drawing.Point(197, 260);
            this.txtComercial.Name = "txtComercial";
            this.txtComercial.Size = new System.Drawing.Size(175, 20);
            this.txtComercial.TabIndex = 93;
            // 
            // txtLocalidade
            // 
            this.txtLocalidade.Location = new System.Drawing.Point(802, 106);
            this.txtLocalidade.Name = "txtLocalidade";
            this.txtLocalidade.Size = new System.Drawing.Size(186, 20);
            this.txtLocalidade.TabIndex = 71;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(193, 237);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(134, 20);
            this.label21.TabIndex = 92;
            this.label21.Text = "C. Art. Comercial";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(10, 132);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(33, 20);
            this.label11.TabIndex = 72;
            this.label11.Text = "Fax";
            // 
            // txtContaEmpresa
            // 
            this.txtContaEmpresa.Location = new System.Drawing.Point(13, 260);
            this.txtContaEmpresa.Name = "txtContaEmpresa";
            this.txtContaEmpresa.Size = new System.Drawing.Size(178, 20);
            this.txtContaEmpresa.TabIndex = 91;
            // 
            // txtFax
            // 
            this.txtFax.Location = new System.Drawing.Point(13, 156);
            this.txtFax.Name = "txtFax";
            this.txtFax.Size = new System.Drawing.Size(175, 20);
            this.txtFax.TabIndex = 73;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(10, 237);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(121, 20);
            this.label20.TabIndex = 90;
            this.label20.Text = "Conta Empresa";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(190, 132);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(71, 20);
            this.label12.TabIndex = 74;
            this.label12.Text = "Telefone";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(798, 179);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(115, 20);
            this.label19.TabIndex = 89;
            this.label19.Text = "Forma Júridica";
            // 
            // txtTelefone
            // 
            this.txtTelefone.Location = new System.Drawing.Point(197, 156);
            this.txtTelefone.Name = "txtTelefone";
            this.txtTelefone.Size = new System.Drawing.Size(183, 20);
            this.txtTelefone.TabIndex = 75;
            // 
            // txtFormaJuridica
            // 
            this.txtFormaJuridica.Location = new System.Drawing.Point(802, 203);
            this.txtFormaJuridica.Name = "txtFormaJuridica";
            this.txtFormaJuridica.Size = new System.Drawing.Size(186, 20);
            this.txtFormaJuridica.TabIndex = 88;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(394, 132);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(111, 20);
            this.label13.TabIndex = 76;
            this.label13.Text = "Coordenadas";
            // 
            // txtSituacao
            // 
            this.txtSituacao.Location = new System.Drawing.Point(598, 204);
            this.txtSituacao.Name = "txtSituacao";
            this.txtSituacao.Size = new System.Drawing.Size(186, 20);
            this.txtSituacao.TabIndex = 87;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(594, 179);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(73, 20);
            this.label18.TabIndex = 86;
            this.label18.Text = "Situação";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(798, 129);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(165, 20);
            this.label14.TabIndex = 78;
            this.label14.Text = "Data de Constituição";
            // 
            // txtCapital
            // 
            this.txtCapital.Location = new System.Drawing.Point(398, 204);
            this.txtCapital.Name = "txtCapital";
            this.txtCapital.Size = new System.Drawing.Size(186, 20);
            this.txtCapital.TabIndex = 85;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(10, 179);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(145, 20);
            this.label15.TabIndex = 79;
            this.label15.Text = "Nº de Funcionários";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(394, 179);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(109, 20);
            this.label17.TabIndex = 84;
            this.label17.Text = "Capital Social";
            // 
            // txtMulheres
            // 
            this.txtMulheres.Font = new System.Drawing.Font("Century", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMulheres.ForeColor = System.Drawing.Color.Black;
            this.txtMulheres.Location = new System.Drawing.Point(13, 203);
            this.txtMulheres.Name = "txtMulheres";
            this.txtMulheres.Size = new System.Drawing.Size(86, 21);
            this.txtMulheres.TabIndex = 80;
            this.txtMulheres.Text = "Mulheres";
            this.txtMulheres.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtVVendas
            // 
            this.txtVVendas.Location = new System.Drawing.Point(197, 204);
            this.txtVVendas.Name = "txtVVendas";
            this.txtVVendas.Size = new System.Drawing.Size(183, 20);
            this.txtVVendas.TabIndex = 83;
            // 
            // txtHomens
            // 
            this.txtHomens.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHomens.ForeColor = System.Drawing.Color.Black;
            this.txtHomens.Location = new System.Drawing.Point(105, 203);
            this.txtHomens.Name = "txtHomens";
            this.txtHomens.Size = new System.Drawing.Size(86, 21);
            this.txtHomens.TabIndex = 81;
            this.txtHomens.Text = "Homens";
            this.txtHomens.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(193, 179);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(149, 20);
            this.label16.TabIndex = 82;
            this.label16.Text = "Volume de Vendas";
            // 
            // btnAjuda
            // 
            this.btnAjuda.BackColor = System.Drawing.Color.Transparent;
            this.btnAjuda.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAjuda.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAjuda.ForeColor = System.Drawing.Color.White;
            this.btnAjuda.Location = new System.Drawing.Point(0, 298);
            this.btnAjuda.Name = "btnAjuda";
            this.btnAjuda.Size = new System.Drawing.Size(248, 35);
            this.btnAjuda.TabIndex = 20;
            this.btnAjuda.Text = "Ajuda";
            this.btnAjuda.UseVisualStyleBackColor = false;
            this.btnAjuda.Click += new System.EventHandler(this.btnAjuda_Click);
            // 
            // btnFechar
            // 
            this.btnFechar.BackColor = System.Drawing.Color.Transparent;
            this.btnFechar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFechar.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFechar.ForeColor = System.Drawing.Color.White;
            this.btnFechar.Location = new System.Drawing.Point(0, 258);
            this.btnFechar.Name = "btnFechar";
            this.btnFechar.Size = new System.Drawing.Size(248, 35);
            this.btnFechar.TabIndex = 19;
            this.btnFechar.Text = "Fechar";
            this.btnFechar.UseVisualStyleBackColor = false;
            this.btnFechar.Click += new System.EventHandler(this.btnFechar_Click);
            // 
            // btnAlterar
            // 
            this.btnAlterar.BackColor = System.Drawing.Color.Transparent;
            this.btnAlterar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAlterar.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAlterar.ForeColor = System.Drawing.Color.White;
            this.btnAlterar.Location = new System.Drawing.Point(0, 176);
            this.btnAlterar.Name = "btnAlterar";
            this.btnAlterar.Size = new System.Drawing.Size(248, 35);
            this.btnAlterar.TabIndex = 18;
            this.btnAlterar.Text = "Alterar";
            this.btnAlterar.UseVisualStyleBackColor = false;
            this.btnAlterar.Click += new System.EventHandler(this.btnAlterar_Click);
            // 
            // btnSEmpresa
            // 
            this.btnSEmpresa.BackColor = System.Drawing.Color.Transparent;
            this.btnSEmpresa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSEmpresa.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSEmpresa.ForeColor = System.Drawing.Color.White;
            this.btnSEmpresa.Location = new System.Drawing.Point(0, 140);
            this.btnSEmpresa.Name = "btnSEmpresa";
            this.btnSEmpresa.Size = new System.Drawing.Size(248, 35);
            this.btnSEmpresa.TabIndex = 17;
            this.btnSEmpresa.Text = "Sócios da Empresa";
            this.btnSEmpresa.UseVisualStyleBackColor = false;
            // 
            // btnEstEmpresa
            // 
            this.btnEstEmpresa.BackColor = System.Drawing.Color.Transparent;
            this.btnEstEmpresa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEstEmpresa.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEstEmpresa.ForeColor = System.Drawing.Color.White;
            this.btnEstEmpresa.Location = new System.Drawing.Point(0, 59);
            this.btnEstEmpresa.Name = "btnEstEmpresa";
            this.btnEstEmpresa.Size = new System.Drawing.Size(248, 35);
            this.btnEstEmpresa.TabIndex = 16;
            this.btnEstEmpresa.Text = "Estabelecimentos da Empresa";
            this.btnEstEmpresa.UseVisualStyleBackColor = false;
            // 
            // btnActividadeEmpresa
            // 
            this.btnActividadeEmpresa.BackColor = System.Drawing.Color.Transparent;
            this.btnActividadeEmpresa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnActividadeEmpresa.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnActividadeEmpresa.ForeColor = System.Drawing.Color.White;
            this.btnActividadeEmpresa.Location = new System.Drawing.Point(0, 100);
            this.btnActividadeEmpresa.Name = "btnActividadeEmpresa";
            this.btnActividadeEmpresa.Size = new System.Drawing.Size(248, 35);
            this.btnActividadeEmpresa.TabIndex = 15;
            this.btnActividadeEmpresa.Text = "Actividades da Empresa";
            this.btnActividadeEmpresa.UseVisualStyleBackColor = false;
            this.btnActividadeEmpresa.Click += new System.EventHandler(this.btnActividadeEmpresa_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel4.Controls.Add(this.btnEliminar);
            this.panel4.Controls.Add(this.btnNovoRegistro);
            this.panel4.Controls.Add(this.btnAjuda);
            this.panel4.Controls.Add(this.btnEstEmpresa);
            this.panel4.Controls.Add(this.btnFechar);
            this.panel4.Controls.Add(this.btnActividadeEmpresa);
            this.panel4.Controls.Add(this.btnAlterar);
            this.panel4.Controls.Add(this.btnSEmpresa);
            this.panel4.Location = new System.Drawing.Point(1, 124);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(252, 350);
            this.panel4.TabIndex = 2;
            // 
            // btnNovoRegistro
            // 
            this.btnNovoRegistro.BackColor = System.Drawing.Color.Transparent;
            this.btnNovoRegistro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNovoRegistro.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNovoRegistro.ForeColor = System.Drawing.Color.White;
            this.btnNovoRegistro.Location = new System.Drawing.Point(0, 20);
            this.btnNovoRegistro.Name = "btnNovoRegistro";
            this.btnNovoRegistro.Size = new System.Drawing.Size(249, 35);
            this.btnNovoRegistro.TabIndex = 21;
            this.btnNovoRegistro.Text = "Novo Registro";
            this.btnNovoRegistro.UseVisualStyleBackColor = false;
            this.btnNovoRegistro.Click += new System.EventHandler(this.btnNovoRegistro_Click);
            // 
            // btnEliminar
            // 
            this.btnEliminar.BackColor = System.Drawing.Color.Transparent;
            this.btnEliminar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEliminar.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEliminar.ForeColor = System.Drawing.Color.White;
            this.btnEliminar.Location = new System.Drawing.Point(0, 217);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(248, 35);
            this.btnEliminar.TabIndex = 22;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.UseVisualStyleBackColor = false;
            this.btnEliminar.Click += new System.EventHandler(this.btnEliminar_Click);
            // 
            // FueEmpresa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(1250, 507);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "FueEmpresa";
            this.Text = "AlterarEmpresa";
            this.Load += new System.EventHandler(this.FueEmpresa_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtDoc;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtNuit;
        private System.Windows.Forms.TextBox txtNine;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtNrEstabelecimentos;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dtpDocumentoRecente;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.DateTimePicker dtpConstituicao;
        private System.Windows.Forms.TextBox txtAbreviatura;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtGci;
        private System.Windows.Forms.TextBox txtMorada;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtEst;
        private System.Windows.Forms.TextBox txtCPostal;
        private System.Windows.Forms.TextBox txtPriv;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtPub;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtSector;
        private System.Windows.Forms.TextBox txtUrl;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtComercial;
        private System.Windows.Forms.TextBox txtLocalidade;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtContaEmpresa;
        private System.Windows.Forms.TextBox txtFax;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtTelefone;
        private System.Windows.Forms.TextBox txtFormaJuridica;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtSituacao;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtCapital;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtMulheres;
        private System.Windows.Forms.TextBox txtVVendas;
        private System.Windows.Forms.TextBox txtHomens;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button btnSEmpresa;
        private System.Windows.Forms.Button btnEstEmpresa;
        private System.Windows.Forms.Button btnActividadeEmpresa;
        private System.Windows.Forms.Button btnAlterar;
        private System.Windows.Forms.Button btnAjuda;
        private System.Windows.Forms.Button btnFechar;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TextBox txtAlt;
        private System.Windows.Forms.TextBox txtLong;
        private System.Windows.Forms.TextBox txtLat;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnNovoRegistro;
        private System.Windows.Forms.Button btnPesquisar;
        private System.Windows.Forms.Button btnEliminar;
    }
}