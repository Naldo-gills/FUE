﻿
namespace WindowsFormsApp1.Forms
{
    partial class InserirEmpresa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InserirEmpresa));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtNuit = new System.Windows.Forms.TextBox();
            this.txtIne = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtAlt = new System.Windows.Forms.TextBox();
            this.txtLong = new System.Windows.Forms.TextBox();
            this.txtLat = new System.Windows.Forms.TextBox();
            this.txtNrEstabelecimentos = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.dtpDocumentoRecente = new System.Windows.Forms.DateTimePicker();
            this.dtpConstituicao = new System.Windows.Forms.DateTimePicker();
            this.label25 = new System.Windows.Forms.Label();
            this.txtGci = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.txtEst = new System.Windows.Forms.TextBox();
            this.txtPriv = new System.Windows.Forms.TextBox();
            this.txtPub = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.txtSector = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txtComercial = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txtContaEmpresa = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.txtFormaJuridica = new System.Windows.Forms.TextBox();
            this.txtSituacao = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtCapital = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtVVendas = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtHomens = new System.Windows.Forms.TextBox();
            this.txtMulheres = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtTelefone = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtFax = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtLocalidade = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtUrl = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtPostal = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtMorada = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtAbreviatura = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button7 = new System.Windows.Forms.Button();
            this.btnAlterar = new System.Windows.Forms.Button();
            this.btnNovoRegistro = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.btnFechar = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnInserirEmpresa = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.pictureBox9);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.txtNuit);
            this.panel1.Controls.Add(this.txtIne);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.btnClose);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1000, 112);
            this.panel1.TabIndex = 0;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox9.Image")));
            this.pictureBox9.Location = new System.Drawing.Point(16, 3);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(172, 65);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox9.TabIndex = 36;
            this.pictureBox9.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(31, 71);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(227, 25);
            this.label3.TabIndex = 8;
            this.label3.Text = "Registro de Empresas";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(494, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 21);
            this.label2.TabIndex = 7;
            this.label2.Text = "Nº Nuit";
            // 
            // txtNuit
            // 
            this.txtNuit.Location = new System.Drawing.Point(564, 63);
            this.txtNuit.Name = "txtNuit";
            this.txtNuit.Size = new System.Drawing.Size(100, 20);
            this.txtNuit.TabIndex = 5;
            // 
            // txtIne
            // 
            this.txtIne.Location = new System.Drawing.Point(356, 65);
            this.txtIne.Name = "txtIne";
            this.txtIne.Size = new System.Drawing.Size(100, 20);
            this.txtIne.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(293, 64);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 21);
            this.label1.TabIndex = 2;
            this.label1.Text = "Nº INE";
            // 
            // btnClose
            // 
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.ForeColor = System.Drawing.Color.Red;
            this.btnClose.Location = new System.Drawing.Point(973, 0);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(24, 31);
            this.btnClose.TabIndex = 1;
            this.btnClose.Text = "X";
            this.btnClose.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.txtAlt);
            this.panel2.Controls.Add(this.txtLong);
            this.panel2.Controls.Add(this.txtLat);
            this.panel2.Controls.Add(this.txtNrEstabelecimentos);
            this.panel2.Controls.Add(this.label26);
            this.panel2.Controls.Add(this.dtpDocumentoRecente);
            this.panel2.Controls.Add(this.dtpConstituicao);
            this.panel2.Controls.Add(this.label25);
            this.panel2.Controls.Add(this.txtGci);
            this.panel2.Controls.Add(this.label24);
            this.panel2.Controls.Add(this.txtEst);
            this.panel2.Controls.Add(this.txtPriv);
            this.panel2.Controls.Add(this.txtPub);
            this.panel2.Controls.Add(this.label23);
            this.panel2.Controls.Add(this.txtSector);
            this.panel2.Controls.Add(this.label22);
            this.panel2.Controls.Add(this.txtComercial);
            this.panel2.Controls.Add(this.label21);
            this.panel2.Controls.Add(this.txtContaEmpresa);
            this.panel2.Controls.Add(this.label20);
            this.panel2.Controls.Add(this.label19);
            this.panel2.Controls.Add(this.txtFormaJuridica);
            this.panel2.Controls.Add(this.txtSituacao);
            this.panel2.Controls.Add(this.label18);
            this.panel2.Controls.Add(this.txtCapital);
            this.panel2.Controls.Add(this.label17);
            this.panel2.Controls.Add(this.txtVVendas);
            this.panel2.Controls.Add(this.label16);
            this.panel2.Controls.Add(this.txtHomens);
            this.panel2.Controls.Add(this.txtMulheres);
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.label14);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.txtTelefone);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.txtFax);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.txtLocalidade);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.txtUrl);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.txtEmail);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.txtPostal);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.txtMorada);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.txtAbreviatura);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.txtNome);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel2.Location = new System.Drawing.Point(0, 112);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1000, 488);
            this.panel2.TabIndex = 1;
            // 
            // txtAlt
            // 
            this.txtAlt.Location = new System.Drawing.Point(659, 136);
            this.txtAlt.Name = "txtAlt";
            this.txtAlt.Size = new System.Drawing.Size(118, 21);
            this.txtAlt.TabIndex = 60;
            // 
            // txtLong
            // 
            this.txtLong.Location = new System.Drawing.Point(527, 136);
            this.txtLong.Name = "txtLong";
            this.txtLong.Size = new System.Drawing.Size(118, 21);
            this.txtLong.TabIndex = 59;
            // 
            // txtLat
            // 
            this.txtLat.Location = new System.Drawing.Point(395, 136);
            this.txtLat.Name = "txtLat";
            this.txtLat.Size = new System.Drawing.Size(118, 21);
            this.txtLat.TabIndex = 58;
            // 
            // txtNrEstabelecimentos
            // 
            this.txtNrEstabelecimentos.Location = new System.Drawing.Point(10, 290);
            this.txtNrEstabelecimentos.Name = "txtNrEstabelecimentos";
            this.txtNrEstabelecimentos.Size = new System.Drawing.Size(178, 21);
            this.txtNrEstabelecimentos.TabIndex = 57;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.Red;
            this.label26.Location = new System.Drawing.Point(7, 265);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(182, 20);
            this.label26.TabIndex = 56;
            this.label26.Text = "Nº de Estabelecimentos";
            // 
            // dtpDocumentoRecente
            // 
            this.dtpDocumentoRecente.Location = new System.Drawing.Point(194, 290);
            this.dtpDocumentoRecente.Name = "dtpDocumentoRecente";
            this.dtpDocumentoRecente.Size = new System.Drawing.Size(176, 21);
            this.dtpDocumentoRecente.TabIndex = 55;
            // 
            // dtpConstituicao
            // 
            this.dtpConstituicao.Location = new System.Drawing.Point(799, 134);
            this.dtpConstituicao.Name = "dtpConstituicao";
            this.dtpConstituicao.Size = new System.Drawing.Size(186, 21);
            this.dtpConstituicao.TabIndex = 54;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.Red;
            this.label25.Location = new System.Drawing.Point(190, 265);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(202, 20);
            this.label25.TabIndex = 53;
            this.label25.Text = "Data documento Recente";
            // 
            // txtGci
            // 
            this.txtGci.Location = new System.Drawing.Point(799, 238);
            this.txtGci.Name = "txtGci";
            this.txtGci.Size = new System.Drawing.Size(186, 21);
            this.txtGci.TabIndex = 52;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Red;
            this.label24.Location = new System.Drawing.Point(795, 215);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(39, 20);
            this.label24.TabIndex = 51;
            this.label24.Text = "GCI";
            // 
            // txtEst
            // 
            this.txtEst.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEst.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.txtEst.Location = new System.Drawing.Point(725, 238);
            this.txtEst.Name = "txtEst";
            this.txtEst.Size = new System.Drawing.Size(56, 22);
            this.txtEst.TabIndex = 50;
            // 
            // txtPriv
            // 
            this.txtPriv.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPriv.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.txtPriv.Location = new System.Drawing.Point(660, 238);
            this.txtPriv.Name = "txtPriv";
            this.txtPriv.Size = new System.Drawing.Size(56, 22);
            this.txtPriv.TabIndex = 49;
            // 
            // txtPub
            // 
            this.txtPub.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPub.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.txtPub.Location = new System.Drawing.Point(595, 238);
            this.txtPub.Name = "txtPub";
            this.txtPub.Size = new System.Drawing.Size(56, 22);
            this.txtPub.TabIndex = 48;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.Red;
            this.label23.Location = new System.Drawing.Point(591, 215);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(173, 20);
            this.label23.TabIndex = 47;
            this.label23.Text = "Repartição Do Capital";
            // 
            // txtSector
            // 
            this.txtSector.Location = new System.Drawing.Point(395, 238);
            this.txtSector.Name = "txtSector";
            this.txtSector.Size = new System.Drawing.Size(186, 21);
            this.txtSector.TabIndex = 46;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.Red;
            this.label22.Location = new System.Drawing.Point(391, 215);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(147, 20);
            this.label22.TabIndex = 45;
            this.label22.Text = "Sector Institucional";
            // 
            // txtComercial
            // 
            this.txtComercial.Location = new System.Drawing.Point(194, 238);
            this.txtComercial.Name = "txtComercial";
            this.txtComercial.Size = new System.Drawing.Size(175, 21);
            this.txtComercial.TabIndex = 44;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.Red;
            this.label21.Location = new System.Drawing.Point(190, 215);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(134, 20);
            this.label21.TabIndex = 43;
            this.label21.Text = "C. Art. Comercial";
            // 
            // txtContaEmpresa
            // 
            this.txtContaEmpresa.Location = new System.Drawing.Point(10, 238);
            this.txtContaEmpresa.Name = "txtContaEmpresa";
            this.txtContaEmpresa.Size = new System.Drawing.Size(178, 21);
            this.txtContaEmpresa.TabIndex = 42;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Red;
            this.label20.Location = new System.Drawing.Point(7, 215);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(121, 20);
            this.label20.TabIndex = 41;
            this.label20.Text = "Conta Empresa";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Red;
            this.label19.Location = new System.Drawing.Point(795, 157);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(115, 20);
            this.label19.TabIndex = 40;
            this.label19.Text = "Forma Júridica";
            // 
            // txtFormaJuridica
            // 
            this.txtFormaJuridica.Location = new System.Drawing.Point(799, 181);
            this.txtFormaJuridica.Name = "txtFormaJuridica";
            this.txtFormaJuridica.Size = new System.Drawing.Size(186, 21);
            this.txtFormaJuridica.TabIndex = 39;
            // 
            // txtSituacao
            // 
            this.txtSituacao.Location = new System.Drawing.Point(595, 182);
            this.txtSituacao.Name = "txtSituacao";
            this.txtSituacao.Size = new System.Drawing.Size(186, 21);
            this.txtSituacao.TabIndex = 38;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Red;
            this.label18.Location = new System.Drawing.Point(591, 157);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(73, 20);
            this.label18.TabIndex = 37;
            this.label18.Text = "Situação";
            // 
            // txtCapital
            // 
            this.txtCapital.Location = new System.Drawing.Point(395, 182);
            this.txtCapital.Name = "txtCapital";
            this.txtCapital.Size = new System.Drawing.Size(186, 21);
            this.txtCapital.TabIndex = 36;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Red;
            this.label17.Location = new System.Drawing.Point(391, 157);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(109, 20);
            this.label17.TabIndex = 35;
            this.label17.Text = "Capital Social";
            // 
            // txtVVendas
            // 
            this.txtVVendas.Location = new System.Drawing.Point(194, 182);
            this.txtVVendas.Name = "txtVVendas";
            this.txtVVendas.Size = new System.Drawing.Size(183, 21);
            this.txtVVendas.TabIndex = 34;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Red;
            this.label16.Location = new System.Drawing.Point(190, 157);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(149, 20);
            this.label16.TabIndex = 33;
            this.label16.Text = "Volume de Vendas";
            // 
            // txtHomens
            // 
            this.txtHomens.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHomens.ForeColor = System.Drawing.Color.Red;
            this.txtHomens.Location = new System.Drawing.Point(102, 181);
            this.txtHomens.Name = "txtHomens";
            this.txtHomens.Size = new System.Drawing.Size(86, 21);
            this.txtHomens.TabIndex = 32;
            this.txtHomens.Text = "Homens";
            this.txtHomens.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtMulheres
            // 
            this.txtMulheres.Font = new System.Drawing.Font("Century", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMulheres.ForeColor = System.Drawing.Color.Red;
            this.txtMulheres.Location = new System.Drawing.Point(10, 181);
            this.txtMulheres.Name = "txtMulheres";
            this.txtMulheres.Size = new System.Drawing.Size(86, 21);
            this.txtMulheres.TabIndex = 31;
            this.txtMulheres.Text = "Mulheres";
            this.txtMulheres.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Red;
            this.label15.Location = new System.Drawing.Point(7, 157);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(145, 20);
            this.label15.TabIndex = 30;
            this.label15.Text = "Nº de Funcionários";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Red;
            this.label14.Location = new System.Drawing.Point(795, 107);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(165, 20);
            this.label14.TabIndex = 28;
            this.label14.Text = "Data de Constituição";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Red;
            this.label13.Location = new System.Drawing.Point(391, 110);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(111, 20);
            this.label13.TabIndex = 26;
            this.label13.Text = "Coordenadas";
            // 
            // txtTelefone
            // 
            this.txtTelefone.Location = new System.Drawing.Point(194, 134);
            this.txtTelefone.Name = "txtTelefone";
            this.txtTelefone.Size = new System.Drawing.Size(183, 21);
            this.txtTelefone.TabIndex = 25;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Red;
            this.label12.Location = new System.Drawing.Point(187, 110);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(71, 20);
            this.label12.TabIndex = 24;
            this.label12.Text = "Telefone";
            // 
            // txtFax
            // 
            this.txtFax.Location = new System.Drawing.Point(10, 134);
            this.txtFax.Name = "txtFax";
            this.txtFax.Size = new System.Drawing.Size(175, 21);
            this.txtFax.TabIndex = 23;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Red;
            this.label11.Location = new System.Drawing.Point(7, 110);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(33, 20);
            this.label11.TabIndex = 22;
            this.label11.Text = "Fax";
            // 
            // txtLocalidade
            // 
            this.txtLocalidade.Location = new System.Drawing.Point(799, 84);
            this.txtLocalidade.Name = "txtLocalidade";
            this.txtLocalidade.Size = new System.Drawing.Size(186, 21);
            this.txtLocalidade.TabIndex = 21;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(795, 60);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(92, 20);
            this.label10.TabIndex = 20;
            this.label10.Text = "Localidade";
            // 
            // txtUrl
            // 
            this.txtUrl.Location = new System.Drawing.Point(395, 84);
            this.txtUrl.Name = "txtUrl";
            this.txtUrl.Size = new System.Drawing.Size(386, 21);
            this.txtUrl.TabIndex = 19;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(391, 60);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(36, 20);
            this.label9.TabIndex = 18;
            this.label9.Text = "URL";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(10, 84);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(367, 21);
            this.txtEmail.TabIndex = 17;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(6, 60);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(51, 20);
            this.label8.TabIndex = 16;
            this.label8.Text = "E-mail";
            // 
            // txtPostal
            // 
            this.txtPostal.Location = new System.Drawing.Point(799, 37);
            this.txtPostal.Name = "txtPostal";
            this.txtPostal.Size = new System.Drawing.Size(186, 21);
            this.txtPostal.TabIndex = 15;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(795, 13);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 20);
            this.label7.TabIndex = 14;
            this.label7.Text = "C. Postal";
            // 
            // txtMorada
            // 
            this.txtMorada.Location = new System.Drawing.Point(595, 37);
            this.txtMorada.Name = "txtMorada";
            this.txtMorada.Size = new System.Drawing.Size(186, 21);
            this.txtMorada.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(591, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 20);
            this.label6.TabIndex = 12;
            this.label6.Text = "Morada";
            // 
            // txtAbreviatura
            // 
            this.txtAbreviatura.Location = new System.Drawing.Point(395, 37);
            this.txtAbreviatura.Name = "txtAbreviatura";
            this.txtAbreviatura.Size = new System.Drawing.Size(186, 21);
            this.txtAbreviatura.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(391, 13);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 20);
            this.label5.TabIndex = 11;
            this.label5.Text = "Abreviatura";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(10, 37);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(367, 21);
            this.txtNome.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(6, 13);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 20);
            this.label4.TabIndex = 10;
            this.label4.Text = "Nome";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.button7);
            this.panel3.Controls.Add(this.btnAlterar);
            this.panel3.Controls.Add(this.btnNovoRegistro);
            this.panel3.Controls.Add(this.button4);
            this.panel3.Controls.Add(this.button3);
            this.panel3.Controls.Add(this.btnFechar);
            this.panel3.Controls.Add(this.button1);
            this.panel3.Controls.Add(this.btnInserirEmpresa);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 343);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1000, 145);
            this.panel3.TabIndex = 0;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Red;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.Location = new System.Drawing.Point(6, 94);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(242, 35);
            this.button7.TabIndex = 13;
            this.button7.Text = "Sócios da Empresa";
            this.button7.UseVisualStyleBackColor = false;
            // 
            // btnAlterar
            // 
            this.btnAlterar.BackColor = System.Drawing.Color.Red;
            this.btnAlterar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAlterar.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAlterar.ForeColor = System.Drawing.Color.White;
            this.btnAlterar.Location = new System.Drawing.Point(554, 41);
            this.btnAlterar.Name = "btnAlterar";
            this.btnAlterar.Size = new System.Drawing.Size(148, 35);
            this.btnAlterar.TabIndex = 12;
            this.btnAlterar.Text = "Alterar";
            this.btnAlterar.UseVisualStyleBackColor = false;
            this.btnAlterar.Click += new System.EventHandler(this.btnAlterar_Click);
            // 
            // btnNovoRegistro
            // 
            this.btnNovoRegistro.BackColor = System.Drawing.Color.Red;
            this.btnNovoRegistro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNovoRegistro.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNovoRegistro.ForeColor = System.Drawing.Color.White;
            this.btnNovoRegistro.Location = new System.Drawing.Point(390, 41);
            this.btnNovoRegistro.Name = "btnNovoRegistro";
            this.btnNovoRegistro.Size = new System.Drawing.Size(148, 35);
            this.btnNovoRegistro.TabIndex = 11;
            this.btnNovoRegistro.Text = "Novo Registro";
            this.btnNovoRegistro.UseVisualStyleBackColor = false;
            this.btnNovoRegistro.Click += new System.EventHandler(this.btnNovoRegistro_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Red;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(837, 94);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(148, 35);
            this.button4.TabIndex = 10;
            this.button4.Text = "Ajuda";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Red;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(837, 12);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(148, 35);
            this.button3.TabIndex = 9;
            this.button3.Text = "Observações";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // btnFechar
            // 
            this.btnFechar.BackColor = System.Drawing.Color.Red;
            this.btnFechar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFechar.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFechar.ForeColor = System.Drawing.Color.White;
            this.btnFechar.Location = new System.Drawing.Point(837, 53);
            this.btnFechar.Name = "btnFechar";
            this.btnFechar.Size = new System.Drawing.Size(148, 35);
            this.btnFechar.TabIndex = 8;
            this.btnFechar.Text = "Fechar";
            this.btnFechar.UseVisualStyleBackColor = false;
            this.btnFechar.Click += new System.EventHandler(this.btnFechar_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Red;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(6, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(242, 35);
            this.button1.TabIndex = 7;
            this.button1.Text = "Estabelecimentos da Empresa";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // btnInserirEmpresa
            // 
            this.btnInserirEmpresa.BackColor = System.Drawing.Color.Red;
            this.btnInserirEmpresa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnInserirEmpresa.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInserirEmpresa.ForeColor = System.Drawing.Color.White;
            this.btnInserirEmpresa.Location = new System.Drawing.Point(6, 53);
            this.btnInserirEmpresa.Name = "btnInserirEmpresa";
            this.btnInserirEmpresa.Size = new System.Drawing.Size(242, 35);
            this.btnInserirEmpresa.TabIndex = 6;
            this.btnInserirEmpresa.Text = "Actividades da Empresa";
            this.btnInserirEmpresa.UseVisualStyleBackColor = false;
            this.btnInserirEmpresa.Click += new System.EventHandler(this.btnInserirEmpresa_Click);
            // 
            // InserirEmpresa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 600);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "InserirEmpresa";
            this.Text = "InserirEmpresa";
            this.Load += new System.EventHandler(this.InserirEmpresa_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtNuit;
        private System.Windows.Forms.TextBox txtIne;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.TextBox txtPostal;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtMorada;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtAbreviatura;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtTelefone;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtFax;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtLocalidade;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtUrl;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtFormaJuridica;
        private System.Windows.Forms.TextBox txtSituacao;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtCapital;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtVVendas;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtHomens;
        private System.Windows.Forms.TextBox txtMulheres;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtNrEstabelecimentos;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.DateTimePicker dtpDocumentoRecente;
        private System.Windows.Forms.DateTimePicker dtpConstituicao;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtGci;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtEst;
        private System.Windows.Forms.TextBox txtPriv;
        private System.Windows.Forms.TextBox txtPub;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtSector;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtComercial;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtContaEmpresa;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button btnAlterar;
        private System.Windows.Forms.Button btnNovoRegistro;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button btnFechar;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnInserirEmpresa;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.TextBox txtAlt;
        private System.Windows.Forms.TextBox txtLong;
        private System.Windows.Forms.TextBox txtLat;
    }
}